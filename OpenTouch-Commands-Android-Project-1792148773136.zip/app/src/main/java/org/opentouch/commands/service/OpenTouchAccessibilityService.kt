package org.opentouch.commands.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.util.Log
import kotlinx.coroutines.*
import org.opentouch.commands.model.TouchAction
import org.opentouch.commands.model.MacroCommand

/**
 * OpenTouchAccessibilityService
 * Executes touch sequences without requiring root access on Android 8.0+
 * Supports OriginOS 6, ColorOS 14, HyperOS, and AOSP.
 */
class OpenTouchAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var isPlaying = false

    companion object {
        private const val TAG = "OpenTouchService"
        var instance: OpenTouchAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "OpenTouch Accessibility Service connected and ready.")
    }

    override fun onInterrupt() {
        Log.w(TAG, "Accessibility Service interrupted.")
        stopPlayback()
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        serviceScope.cancel()
    }

    /**
     * Dispatch a single tap gesture at absolute screen coordinates
     */
    fun dispatchTap(x: Float, y: Float, durationMs: Long = 50L, callback: (() -> Unit)? = null) {
        val path = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs.coerceAtLeast(10L))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                callback?.invoke()
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                Log.w(TAG, "Tap gesture was cancelled at ($x, $y)")
                callback?.invoke()
            }
        }, null)
    }

    /**
     * Dispatch a swipe/drag gesture
     */
    fun dispatchSwipe(
        startX: Float, startY: Float,
        endX: Float, endY: Float,
        durationMs: Long = 300L,
        callback: (() -> Unit)? = null
    ) {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                callback?.invoke()
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                callback?.invoke()
            }
        }, null)
    }

    fun stopPlayback() {
        isPlaying = false
    }
}